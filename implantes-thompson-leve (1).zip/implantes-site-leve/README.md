# Implantes Dentários — Clínica Thompson (versão leve)

Mesma landing page de antes, só que agora otimizada:
- As imagens saíram de dentro do HTML (base64) e viraram arquivos separados na pasta `images/`.
- Fotos redimensionadas e comprimidas (mantendo a qualidade visual) e o logo continua em PNG com fundo transparente.
- Site inteiro: ~3,1 MB → ~1,1 MB.

## Subir para o GitHub

```bash
cd implantes-site-leve
git init
git add .
git commit -m "Landing page Implantes Dentarios - Clinica Thompson (otimizada)"
```

Crie um repositório vazio em https://github.com/new (ex: `implantes-thompson`), depois:

```bash
git remote add origin https://github.com/SEU-USUARIO/implantes-thompson.git
git branch -M main
git push -u origin main
```

## Publicar na Vercel

1. https://vercel.com → **Add New → Project**
2. Selecione o repositório `implantes-thompson`
3. Framework Preset: **Other** (sem build)
4. **Deploy**

No ar em `implantes-thompson.vercel.app` em menos de um minuto. Domínio próprio: **Settings → Domains** no painel do projeto.

## Título e meta description (adicionar depois via editor/SEO)
- Título: `Implantes Dentários de Alta Tecnologia | Clínica Thompson — Santana, SP`
- Meta description: `Implantes dentários com protocolo de carga imediata, planejamento digital e cirurgia guiada. Método Hori de excelência comprovada na Clínica Thompson, Santana, Zona Norte SP.`
